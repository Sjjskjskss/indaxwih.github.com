export interface WithdrawalRequest {
  id: string;
  number: string;
  amount: number;
  method: 'Bkash' | 'Nagad';
  status: 'pending' | 'approved' | 'rejected';
  timestamp: number;
}

export interface Transaction {
  id: string;
  type: 'spin' | 'scratch' | 'ad' | 'bonus' | 'task' | 'game' | 'visit' | 'admin';
  amount: number;
  timestamp: number;
}

export interface UserState {
  balance: number;
  adsWatched: number;
  transactions: Transaction[];
}

export interface Task {
  id: string;
  title: string;
  reward: number;
  link: string;
  icon: 'youtube' | 'telegram' | 'star' | 'download' | 'globe';
  color: string;
}

export type AppTheme = 'light' | 'dark' | 'glass';

export interface AppSettings {
  telegramLink: string;
  whatsappLink: string;
  supportLink: string;
  adZoneId: string;
  theme: AppTheme;
}

export interface AppContextType {
  user: UserState;
  requests: WithdrawalRequest[];
  tasks: Task[];
  settings: AppSettings;
  addBalance: (amount: number, type: Transaction['type']) => void;
  createWithdrawal: (number: string, amount: number, method: 'Bkash' | 'Nagad') => void;
  updateRequestStatus: (id: string, status: 'approved' | 'rejected') => void;
  incrementAds: () => void;
  triggerAd: () => Promise<void>;
  // Admin Actions
  addTask: (task: Task) => void;
  deleteTask: (taskId: string) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  adminUpdateUser: (action: 'reset' | 'deduct' | 'add', amount?: number) => void;
  toggleTheme: () => void;
}
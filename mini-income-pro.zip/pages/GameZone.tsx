import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { CURRENCY_SYMBOL } from '../constants';
import { Button } from '../components/Button';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Gamepad2, CircleDashed, Gift, Calculator, Dices, 
  Coins, Type, Shuffle, X, Trophy, ArrowLeft, Play
} from 'lucide-react';

// --- Assets & Constants ---
const GAMES = [
  { id: 'spin', name: 'Spin Wheel', icon: CircleDashed, color: 'bg-orange-100 text-orange-600', reward: '5' },
  { id: 'scratch', name: 'Scratch Card', icon: Gift, color: 'bg-pink-100 text-pink-600', reward: '3' },
  { id: 'slots', name: 'Neon Slots', icon: Gamepad2, color: 'bg-purple-100 text-purple-600', reward: '10' },
  { id: 'coin', name: '3D Flip', icon: Coins, color: 'bg-yellow-100 text-yellow-600', reward: '2' },
  { id: 'dice', name: 'Cyber Dice', icon: Dices, color: 'bg-green-100 text-green-600', reward: '3' },
  { id: 'math', name: 'Math Rush', icon: Calculator, color: 'bg-blue-100 text-blue-600', reward: '1' },
  { id: 'captcha', name: 'Hacker Code', icon: Type, color: 'bg-red-100 text-red-600', reward: '0.5' },
  { id: 'scramble', name: 'Word Link', icon: Shuffle, color: 'bg-teal-100 text-teal-600', reward: '1' },
];

const SLOT_ICONS = ['🍒', '💎', '7️⃣', '🔔', '🍇'];

// --- Sub Components ---

const SlotReel: React.FC<{ index: number; spinning: boolean; result: string }> = ({ index, spinning, result }) => {
    const [currentIcon, setCurrentIcon] = useState(SLOT_ICONS[0]);

    useEffect(() => {
        if (spinning) {
            const interval = setInterval(() => {
                setCurrentIcon(SLOT_ICONS[Math.floor(Math.random() * SLOT_ICONS.length)]);
            }, 80); // Fast switching
            return () => clearInterval(interval);
        } else {
            setCurrentIcon(result);
        }
    }, [spinning, result]);

    return (
        <div className="w-16 h-24 bg-black/40 border-2 border-purple-500/50 backdrop-blur-sm rounded-lg flex items-center justify-center text-4xl overflow-hidden relative shadow-[0_0_15px_rgba(168,85,247,0.4)]">
            <motion.div
                key={spinning ? 'spin' : 'stop'}
                animate={spinning ? { y: [0, 50, -50, 0], filter: 'blur(4px)' } : { y: 0, filter: 'blur(0px)' }}
                transition={spinning ? { repeat: Infinity, duration: 0.2 } : { type: 'spring', stiffness: 300, damping: 20 }}
            >
                {currentIcon}
            </motion.div>
        </div>
    );
};

const ThreeDCoin: React.FC<{ result: 'Heads' | 'Tails'; flipping: boolean }> = ({ result, flipping }) => {
    return (
        <div className="perspective-1000 w-32 h-32 mx-auto">
            <motion.div
                className="w-full h-full relative"
                style={{ transformStyle: 'preserve-3d' }}
                animate={{ rotateY: flipping ? 1800 + (result === 'Tails' ? 180 : 0) : (result === 'Tails' ? 180 : 0) }}
                transition={{ duration: 2, ease: "easeOut" }}
            >
                <div className="absolute inset-0 w-full h-full rounded-full bg-yellow-400 border-4 border-yellow-600 flex items-center justify-center backface-hidden shadow-xl" style={{ backfaceVisibility: 'hidden' }}>
                     <span className="text-4xl font-bold text-yellow-700">H</span>
                     <div className="absolute inset-1 rounded-full border border-yellow-200 opacity-50"></div>
                </div>
                <div className="absolute inset-0 w-full h-full rounded-full bg-gray-300 border-4 border-gray-400 flex items-center justify-center shadow-xl" style={{ transform: 'rotateY(180deg)', backfaceVisibility: 'hidden' }}>
                     <span className="text-4xl font-bold text-gray-600">T</span>
                     <div className="absolute inset-1 rounded-full border border-white opacity-50"></div>
                </div>
            </motion.div>
        </div>
    );
};

const ThreeDDice: React.FC<{ result: number; rolling: boolean }> = ({ result, rolling }) => {
    const getRotation = (num: number) => {
        switch(num) {
            case 1: return { rotateX: 0, rotateY: 0 };
            case 6: return { rotateX: 180, rotateY: 0 };
            case 2: return { rotateX: -90, rotateY: 0 };
            case 5: return { rotateX: 90, rotateY: 0 };
            case 3: return { rotateX: 0, rotateY: -90 };
            case 4: return { rotateX: 0, rotateY: 90 };
            default: return { rotateX: 0, rotateY: 0 };
        }
    };
    const target = getRotation(result);

    return (
         <div className="perspective-1000 w-24 h-24 mx-auto my-6">
            <motion.div
                className="w-full h-full relative"
                style={{ transformStyle: 'preserve-3d' }}
                animate={rolling ? 
                    { rotateX: [0, 360, 720, target.rotateX], rotateY: [0, 360, 720, target.rotateY] } : 
                    { rotateX: target.rotateX, rotateY: target.rotateY }
                }
                transition={{ duration: 1.5, ease: "easeOut" }}
            >
                <div className="absolute inset-0 bg-white border-2 border-gray-200 flex items-center justify-center text-3xl font-bold" style={{ transform: 'translateZ(48px)' }}>1</div>
                <div className="absolute inset-0 bg-white border-2 border-gray-200 flex items-center justify-center text-3xl font-bold" style={{ transform: 'rotateY(180deg) translateZ(48px)' }}>6</div>
                <div className="absolute inset-0 bg-white border-2 border-gray-200 flex items-center justify-center text-3xl font-bold" style={{ transform: 'rotateX(90deg) translateZ(48px)' }}>2</div>
                <div className="absolute inset-0 bg-white border-2 border-gray-200 flex items-center justify-center text-3xl font-bold" style={{ transform: 'rotateX(-90deg) translateZ(48px)' }}>5</div>
                <div className="absolute inset-0 bg-white border-2 border-gray-200 flex items-center justify-center text-3xl font-bold" style={{ transform: 'rotateY(-90deg) translateZ(48px)' }}>3</div>
                <div className="absolute inset-0 bg-white border-2 border-gray-200 flex items-center justify-center text-3xl font-bold" style={{ transform: 'rotateY(90deg) translateZ(48px)' }}>4</div>
            </motion.div>
         </div>
    );
};

// --- Main Component ---

const GameZone: React.FC = () => {
  const navigate = useNavigate();
  const { addBalance, triggerAd, settings } = useApp();
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [resultMessage, setResultMessage] = useState<{ text: string, type: 'win' | 'lose' | 'neutral' } | null>(null);

  // Game States
  const [mathProblem, setMathProblem] = useState({ q: '', a: 0 });
  const [slotResult, setSlotResult] = useState(['7️⃣', '7️⃣', '7️⃣']);
  const [coinSide, setCoinSide] = useState<'Heads' | 'Tails'>('Heads');
  const [diceNum, setDiceNum] = useState(1);
  const [captchaCode, setCaptchaCode] = useState('');
  const [scrambleWord, setScrambleWord] = useState({ original: '', scrambled: '' });
  const [inputValue, setInputValue] = useState('');
  const [loadingGame, setLoadingGame] = useState<string | null>(null);

  const openGame = async (id: string) => {
    // 1. Show Ad First
    setLoadingGame(id);
    await triggerAd();
    setLoadingGame(null);

    // 2. Navigation Logic
    if (id === 'spin') return navigate('/spin');
    if (id === 'scratch') return navigate('/scratch');

    // 3. Open Mini Game Modal
    setActiveGame(id);
    setResultMessage(null);
    setInputValue('');
    setIsPlaying(false);

    // Setup Game
    if (id === 'math') {
        generateMath();
    } else if (id === 'captcha') {
        generateCaptcha();
    } else if (id === 'scramble') {
        generateScramble();
    } else if (id === 'slots') {
        setSlotResult(SLOT_ICONS.slice(0,3));
    }
  };

  const closeGame = () => {
      setActiveGame(null);
  };

  // Logic Generators (Same as before)
  const generateMath = () => {
      const a = Math.floor(Math.random() * 20) + 5;
      const b = Math.floor(Math.random() * 20) + 5;
      const op = Math.random() > 0.5 ? '+' : '-';
      if (op === '-' && b > a) {
          setMathProblem({ q: `${b} - ${a}`, a: b - a });
      } else {
          setMathProblem({ q: `${a} ${op} ${b}`, a: op === '+' ? a + b : a - b });
      }
      setInputValue('');
  };

  const generateCaptcha = () => {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      let result = '';
      for (let i = 0; i < 6; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
      setCaptchaCode(result);
      setInputValue('');
  };

  const generateScramble = () => {
      const words = ['BONUS', 'MONEY', 'LUCKY', 'PRIZE', 'WINNER', 'LEVEL', 'GAMER'];
      const w = words[Math.floor(Math.random() * words.length)];
      const s = w.split('').sort(() => 0.5 - Math.random()).join('');
      setScrambleWord({ original: w, scrambled: s });
      setInputValue('');
  };

  // Handlers
  const handleReward = (amount: number, msg: string) => {
      setResultMessage({ text: msg, type: 'win' });
      addBalance(amount, 'game');
      if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
  };

  const handleLoss = (msg: string) => {
      setResultMessage({ text: msg, type: 'lose' });
      if (navigator.vibrate) navigator.vibrate(200);
  };

  // Action Handlers
  const onSlotSpin = async () => {
      if (isPlaying) return;
      setIsPlaying(true);
      setResultMessage(null);
      
      setTimeout(() => {
          setIsPlaying(false);
          const r1 = SLOT_ICONS[Math.floor(Math.random() * SLOT_ICONS.length)];
          const r2 = SLOT_ICONS[Math.floor(Math.random() * SLOT_ICONS.length)];
          const r3 = SLOT_ICONS[Math.floor(Math.random() * SLOT_ICONS.length)];
          setSlotResult([r1, r2, r3]);

          if (r1 === r2 && r2 === r3) handleReward(10, 'JACKPOT! +10');
          else if (r1 === r2 || r2 === r3 || r1 === r3) handleReward(2, 'Nice Pair! +2');
          else handleLoss('Try Again');
      }, 2000);
  };

  const onCoinFlip = (guess: 'Heads' | 'Tails') => {
      if (isPlaying) return;
      setIsPlaying(true);
      setResultMessage(null);
      const result = Math.random() > 0.5 ? 'Heads' : 'Tails';
      setCoinSide(result);
      setTimeout(() => {
          setIsPlaying(false);
          if (guess === result) handleReward(2, 'You Guessed It! +2');
          else handleLoss('Wrong Guess');
      }, 2000);
  };

  const onDiceRoll = (guess: number) => {
      if (isPlaying) return;
      setIsPlaying(true);
      setResultMessage(null);
      const res = Math.floor(Math.random() * 6) + 1;
      setDiceNum(res);
      setTimeout(() => {
          setIsPlaying(false);
          if (guess === res) handleReward(3, 'Perfect Roll! +3');
          else handleLoss(`Rolled ${res}. Try again.`);
      }, 1500);
  };

  const onSubmitMath = () => {
      if (parseInt(inputValue) === mathProblem.a) {
          handleReward(1, 'Correct! +1');
          setTimeout(generateMath, 1500);
      } else {
          handleLoss('Wrong Answer');
      }
  };

  const onSubmitCaptcha = () => {
      if (inputValue.toUpperCase() === captchaCode) {
          handleReward(0.5, 'Verified! +0.5');
          setTimeout(generateCaptcha, 1500);
      } else {
          handleLoss('Invalid Code');
      }
  };

  const onSubmitScramble = () => {
      if (inputValue.toUpperCase() === scrambleWord.original) {
          handleReward(1, 'Unscrambled! +1');
          setTimeout(generateScramble, 1500);
      } else {
          handleLoss('Not quite right');
      }
  };

  const isDark = settings.theme !== 'light';

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center mb-6">
        <h2 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>Arcade Zone</h2>
        <p className={`${isDark ? 'text-gray-400' : 'text-gray-500'} text-sm`}>Win rewards in every game</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {GAMES.map((game) => (
          <motion.div 
            key={game.id}
            whileHover={{ y: -5 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => openGame(game.id)}
            className={`${isDark ? 'bg-white/5 border-white/10' : 'bg-white border-gray-100'} p-4 rounded-2xl shadow-sm border flex flex-col items-center justify-center text-center cursor-pointer h-40 relative overflow-hidden group`}
          >
             <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-current to-transparent opacity-50 ${game.color.split(' ')[1]}`}></div>
             <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-3 transition-colors ${game.color} group-hover:scale-110 duration-200`}>
                {loadingGame === game.id ? <div className="animate-spin w-6 h-6 border-2 border-current border-t-transparent rounded-full"></div> : <game.icon size={28} />}
             </div>
             <h3 className={`font-bold ${isDark ? 'text-white' : 'text-gray-800'}`}>{game.name}</h3>
             <div className={`flex items-center gap-1 text-[10px] ${isDark ? 'text-gray-300 bg-white/10' : 'text-gray-500 bg-gray-50'} mt-1 font-medium px-2 py-1 rounded-full border border-gray-100/10`}>
                <Trophy size={10} className="text-yellow-500"/>
                Win {CURRENCY_SYMBOL}{game.reward}
             </div>
          </motion.div>
        ))}
      </div>

      {/* Full Screen Game Modal with Glass/Theme support */}
      <AnimatePresence>
        {activeGame && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 bg-black/60 backdrop-blur-sm">
                <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }} 
                    animate={{ scale: 1, opacity: 1 }} 
                    exit={{ scale: 0.9, opacity: 0 }}
                    className={`w-full h-full md:h-auto md:max-w-md md:rounded-3xl p-6 shadow-2xl relative border overflow-y-auto flex flex-col
                        ${settings.theme === 'glass' ? 'bg-black/40 backdrop-blur-2xl border-white/20 text-white' : 
                          settings.theme === 'dark' ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white text-gray-900'}
                    `}
                >
                    {/* Header */}
                    <div className="flex justify-between items-center mb-6 shrink-0">
                         <div className="flex items-center gap-2">
                             {React.createElement(GAMES.find(g => g.id === activeGame)!.icon, { size: 24, className: "text-indigo-500" })}
                             <h3 className="text-xl font-bold uppercase tracking-wider">{GAMES.find(g => g.id === activeGame)?.name}</h3>
                         </div>
                         <div className="flex gap-2">
                            <button onClick={closeGame} className="text-red-400 font-bold text-xs bg-red-500/10 px-3 py-1.5 rounded-full border border-red-500/20 hover:bg-red-500 hover:text-white transition-colors">
                                EXIT GAME
                            </button>
                         </div>
                    </div>

                    {/* Game Content Area */}
                    <div className="flex-1 flex flex-col items-center justify-center relative min-h-[300px]">
                        {/* Background Decor */}
                        <div className="absolute inset-0 bg-[linear-gradient(rgba(100,100,100,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(100,100,100,0.1)_1px,transparent_1px)] bg-[size:20px_20px] -z-10 pointer-events-none"></div>

                        {/* --- SLOTS --- */}
                        {activeGame === 'slots' && (
                            <div className="space-y-8 w-full">
                                <div className="flex justify-center gap-2">
                                    {slotResult.map((icon, i) => (
                                        <SlotReel key={i} index={i} spinning={isPlaying} result={icon} />
                                    ))}
                                </div>
                                <Button 
                                    onClick={onSlotSpin} 
                                    disabled={isPlaying}
                                    className={`w-full bg-gradient-to-r from-purple-600 to-pink-600 border-none shadow-lg shadow-purple-500/30 text-white`}
                                >
                                    {isPlaying ? 'Spinning...' : 'SPIN'}
                                </Button>
                            </div>
                        )}

                        {/* --- COIN FLIP --- */}
                        {activeGame === 'coin' && (
                             <div className="space-y-6 w-full text-center">
                                 <ThreeDCoin result={coinSide} flipping={isPlaying} />
                                 <div className="grid grid-cols-2 gap-4 mt-8">
                                     <Button onClick={() => onCoinFlip('Heads')} disabled={isPlaying} className="bg-yellow-500 hover:bg-yellow-600 text-black border-none shadow-lg shadow-yellow-500/30">HEADS</Button>
                                     <Button onClick={() => onCoinFlip('Tails')} disabled={isPlaying} className="bg-gray-600 hover:bg-gray-700 border-none text-white shadow-lg">TAILS</Button>
                                 </div>
                             </div>
                        )}

                        {/* --- DICE --- */}
                        {activeGame === 'dice' && (
                             <div className="space-y-6 w-full text-center">
                                 <ThreeDDice result={diceNum} rolling={isPlaying} />
                                 <p className="opacity-50 text-sm">Predict the number</p>
                                 <div className="grid grid-cols-3 gap-2">
                                     {[1,2,3,4,5,6].map(n => (
                                         <button
                                            key={n}
                                            disabled={isPlaying}
                                            onClick={() => onDiceRoll(n)}
                                            className="bg-white/10 text-current p-3 rounded-xl border border-white/10 hover:bg-indigo-600 hover:border-indigo-500 transition-all font-bold disabled:opacity-50 backdrop-blur-md"
                                         >
                                             {n}
                                         </button>
                                     ))}
                                 </div>
                             </div>
                        )}

                        {/* --- MATH --- */}
                        {activeGame === 'math' && (
                             <div className="w-full space-y-6">
                                 <div className="bg-white/5 p-6 rounded-2xl border border-white/10 text-center relative overflow-hidden backdrop-blur-md">
                                     <div className="text-4xl font-bold">{mathProblem.q}</div>
                                     <div className="text-xs opacity-50 mt-2">Solve the equation</div>
                                 </div>
                                 <input 
                                     type="number" 
                                     value={inputValue}
                                     onChange={e => setInputValue(e.target.value)}
                                     placeholder="?"
                                     className="w-full bg-white/10 text-center text-2xl p-4 rounded-xl border border-white/10 focus:border-indigo-500 outline-none text-current"
                                 />
                                 <Button onClick={onSubmitMath}>Submit</Button>
                             </div>
                        )}

                        {/* --- CAPTCHA --- */}
                        {activeGame === 'captcha' && (
                             <div className="w-full space-y-6">
                                 <div className="bg-black/50 p-6 rounded-2xl border border-white/10 text-center relative overflow-hidden select-none">
                                     <div className="text-3xl font-mono font-bold text-green-400 tracking-widest" style={{ textShadow: '2px 0 red, -2px 0 blue' }}>
                                         {captchaCode}
                                     </div>
                                 </div>
                                 <input 
                                     type="text" 
                                     value={inputValue}
                                     onChange={e => setInputValue(e.target.value)}
                                     placeholder="Enter Code"
                                     className="w-full bg-white/10 text-center text-xl p-4 rounded-xl border border-white/10 focus:border-green-500 outline-none uppercase font-mono text-current"
                                 />
                                 <Button onClick={onSubmitCaptcha} className="bg-green-600 hover:bg-green-700 border-none text-white">Verify</Button>
                             </div>
                        )}

                         {/* --- SCRAMBLE --- */}
                        {activeGame === 'scramble' && (
                             <div className="w-full space-y-6">
                                 <div className="text-center">
                                     <p className="opacity-50 text-sm mb-2">Unscramble the word</p>
                                     <div className="flex justify-center gap-2">
                                         {scrambleWord.scrambled.split('').map((char, i) => (
                                             <motion.div 
                                                key={i}
                                                initial={{ y: -10, opacity: 0 }}
                                                animate={{ y: 0, opacity: 1 }}
                                                transition={{ delay: i * 0.1 }}
                                                className="w-10 h-10 bg-teal-500/20 border border-teal-500 rounded flex items-center justify-center font-bold text-lg text-teal-400 shadow-[0_0_10px_rgba(20,184,166,0.3)] backdrop-blur-sm"
                                             >
                                                 {char}
                                             </motion.div>
                                         ))}
                                     </div>
                                 </div>
                                 <input 
                                     type="text" 
                                     value={inputValue}
                                     onChange={e => setInputValue(e.target.value)}
                                     placeholder="Type Answer"
                                     className="w-full bg-white/10 text-center text-xl p-4 rounded-xl border border-white/10 focus:border-teal-500 outline-none uppercase text-current"
                                 />
                                 <Button onClick={onSubmitScramble} className="bg-teal-600 hover:bg-teal-700 border-none text-white">Check</Button>
                             </div>
                        )}

                    </div>

                    {/* Result Message Overlay */}
                    <AnimatePresence>
                        {resultMessage && (
                            <motion.div 
                                initial={{ opacity: 0, y: 20 }} 
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0 }}
                                className={`absolute bottom-20 left-6 right-6 p-4 rounded-xl text-center font-bold backdrop-blur-xl border z-20 shadow-xl ${
                                    resultMessage.type === 'win' 
                                    ? 'bg-green-500/20 border-green-500 text-green-400' 
                                    : 'bg-red-500/20 border-red-500 text-red-400'
                                }`}
                            >
                                {resultMessage.text}
                            </motion.div>
                        )}
                    </AnimatePresence>

                    {/* Bottom Back Button specifically for mobile access ease */}
                    <button 
                        onClick={closeGame} 
                        className="mt-6 w-full py-3 bg-white/10 hover:bg-white/20 rounded-xl font-bold text-sm transition-colors border border-white/5"
                    >
                        BACK TO GAMES
                    </button>

                </motion.div>
            </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default GameZone;
import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CURRENCY_SYMBOL } from '../constants';
import { Play, TrendingUp, History, Gift, Globe, ExternalLink, Zap } from 'lucide-react';
import { Button } from '../components/Button';
import { useNavigate } from 'react-router-dom';

const Home: React.FC = () => {
  const { user, addBalance, incrementAds } = useApp();
  const navigate = useNavigate();
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [loadingAdId, setLoadingAdId] = useState<number | null>(null);
  const [visitingId, setVisitingId] = useState<number | null>(null);

  useEffect(() => {
    // Initialize Monetag container ads if available
    try {
      if ((window as any).monetag && typeof (window as any).monetag.all === 'function') {
        (window as any).monetag.all({
            zoneId: "9055411",
            appId: "show_9055411",
            containerId: "monetag-app-box"
        });
      }
    } catch (e) {
      console.error("Monetag init error:", e);
    }
  }, []);

  const handleWatchAd = (id: number = 0) => {
    if (id === 0) setIsWatchingAd(true);
    else setLoadingAdId(id);
    
    // Check for Monetag SDK function 'show_9055411'
    if (typeof (window as any).show_9055411 === 'function') {
      (window as any).show_9055411().then(() => {
        incrementAds();
        addBalance(1, 'ad');
        setIsWatchingAd(false);
        setLoadingAdId(null);
        alert("Ad Watched! Reward: " + CURRENCY_SYMBOL + "1");
      }).catch((e: any) => {
        console.error("Ad failed:", e);
        setIsWatchingAd(false);
        setLoadingAdId(null);
        alert("No ads available at the moment. Please try again later.");
      });
    } else {
      // Fallback simulation if SDK is blocked or not loaded
      setTimeout(() => {
        incrementAds();
        addBalance(1, 'ad');
        setIsWatchingAd(false);
        setLoadingAdId(null);
        alert("Ad Watched (Simulated)! Reward: " + CURRENCY_SYMBOL + "1");
      }, 3000); 
    }
  };

  const visitLinks = [
    { id: 1, url: 'https://www.effectivegatecpm.com/qyt66jpv?key=b28fcc581b4bb9d613e731afb5ccfb5b', label: 'Fast Visit 1', reward: 2.00 },
    { id: 2, url: 'https://www.effectivegatecpm.com/vrjxnpzq8s?key=cb7124f3c1f873f869204eeccaa97682', label: 'Fast Visit 2', reward: 2.00 }
  ];

  const handleVisitWebsite = (id: number, url: string, reward: number) => {
    if (visitingId !== null) return;
    setVisitingId(id);
    
    // Open the ad link
    const win = window.open(url, '_blank');
    
    setTimeout(() => {
        addBalance(reward, 'visit');
        setVisitingId(null);
        alert(`Thanks for visiting! Reward: ${CURRENCY_SYMBOL}${reward.toFixed(2)}`);
        // if (win) win.close(); 
    }, 10000); // 10 seconds delay
  };

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-2xl p-6 text-white shadow-xl shadow-indigo-200 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full -mr-10 -mt-10 blur-2xl"></div>
        <div className="relative z-10">
          <p className="text-indigo-100 text-sm font-medium">Total Balance</p>
          <h2 className="text-4xl font-bold mt-2">{CURRENCY_SYMBOL}{user.balance.toFixed(2)}</h2>
          
          <div className="mt-6 flex gap-4">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3 flex-1">
              <p className="text-xs text-indigo-100">Ads Watched</p>
              <p className="text-xl font-bold">{user.adsWatched}</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3 flex-1">
              <p className="text-xs text-indigo-100">Today's Earn</p>
              <p className="text-xl font-bold">
                 {CURRENCY_SYMBOL}{user.transactions
                    .filter(t => t.timestamp > new Date().setHours(0,0,0,0))
                    .reduce((acc, curr) => acc + curr.amount, 0)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Games Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div 
            onClick={() => navigate('/games')}
            className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 active:scale-95 transition-transform cursor-pointer"
        >
            <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center mb-3">
                <TrendingUp size={20} />
            </div>
            <h3 className="font-bold text-gray-800">Game Zone</h3>
            <p className="text-xs text-gray-500 mt-1">Play 8+ Games</p>
        </div>
        
        <div 
            onClick={() => navigate('/tasks')}
            className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 active:scale-95 transition-transform cursor-pointer"
        >
             <div className="w-10 h-10 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center mb-3">
                <Gift size={20} />
            </div>
            <h3 className="font-bold text-gray-800">Task Wall</h3>
            <p className="text-xs text-gray-500 mt-1">Complete & Earn</p>
        </div>
      </div>

      {/* Monetag Banner Container */}
      <div id="monetag-app-box" className="w-full min-h-[10px] rounded-lg overflow-hidden empty:hidden"></div>

      {/* Main Watch Ad Section */}
      <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                <Play size={20} fill="currentColor" />
            </div>
            <div>
                <h3 className="font-bold text-gray-800">Watch Video</h3>
                <p className="text-xs text-gray-500">High Reward Ad</p>
            </div>
        </div>

        <Button 
            onClick={() => handleWatchAd(0)} 
            isLoading={isWatchingAd}
            className="w-full"
        >
            {isWatchingAd ? 'Loading Ad...' : 'Watch Now'}
        </Button>
      </div>

      {/* 2-Column Bonus Ads */}
      <div className="grid grid-cols-2 gap-4">
          {[1, 2].map((i) => (
             <div key={i} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
                 <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mb-2">
                     <Zap size={16} fill="currentColor" />
                 </div>
                 <h4 className="font-bold text-sm text-gray-700">Bonus Ad #{i}</h4>
                 <p className="text-[10px] text-gray-400 mb-3">+1.00 {CURRENCY_SYMBOL}</p>
                 <Button 
                    variant="outline" 
                    className="w-full py-2 text-xs h-auto"
                    onClick={() => handleWatchAd(i)}
                    isLoading={loadingAdId === i}
                 >
                    {loadingAdId === i ? '...' : 'Claim'}
                 </Button>
             </div>
          ))}
      </div>

      {/* Visit Website Section (Updated) */}
      <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
                <Globe size={20} />
            </div>
            <div>
                <h3 className="font-bold text-gray-800">Visit & Earn</h3>
                <p className="text-xs text-gray-500">Browse for 10s to earn rewards</p>
            </div>
        </div>

        <div className="space-y-3">
            {visitLinks.map((link) => (
                <Button 
                    key={link.id}
                    variant="secondary"
                    onClick={() => handleVisitWebsite(link.id, link.url, link.reward)} 
                    isLoading={visitingId === link.id}
                    disabled={visitingId !== null && visitingId !== link.id}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200 justify-between px-4"
                >
                    <span className="flex items-center gap-2">
                        {visitingId === link.id ? 'Checking...' : <span className="flex items-center gap-2">{link.label} <ExternalLink size={14}/></span>}
                    </span>
                    {!visitingId && (
                        <span className="bg-white/20 text-white text-xs px-2 py-0.5 rounded font-mono">
                            +{CURRENCY_SYMBOL}{link.reward.toFixed(2)}
                        </span>
                    )}
                </Button>
            ))}
        </div>
      </div>

       {/* Recent History */}
       <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
         <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <History size={16} /> Recent Activity
         </h3>
         <div className="space-y-3">
            {user.transactions.length === 0 && <p className="text-gray-400 text-sm text-center py-4">No activity yet</p>}
            {user.transactions.slice(0, 5).map(t => (
                <div key={t.id} className="flex justify-between items-center text-sm border-b border-gray-50 pb-2 last:border-0 last:pb-0">
                    <div>
                        <p className="font-medium text-gray-700 capitalize">{t.type}</p>
                        <p className="text-xs text-gray-400">{new Date(t.timestamp).toLocaleTimeString()}</p>
                    </div>
                    <span className="font-bold text-green-600">+{CURRENCY_SYMBOL}{t.amount}</span>
                </div>
            ))}
         </div>
       </div>

    </div>
  );
};

export default Home;
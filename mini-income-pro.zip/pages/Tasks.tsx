import React from 'react';
import { useApp } from '../context/AppContext';
import { CURRENCY_SYMBOL } from '../constants';
import { Youtube, Send, Star, Download, Globe, HelpCircle } from 'lucide-react';

const Tasks: React.FC = () => {
  const { addBalance, tasks } = useApp();

  // Helper to map string icon names to components
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'youtube': return Youtube;
      case 'telegram': return Send;
      case 'star': return Star;
      case 'download': return Download;
      case 'globe': return Globe;
      default: return HelpCircle;
    }
  };

  const handleTask = (task: any) => {
    window.open(task.link, '_blank');
    setTimeout(() => {
        addBalance(task.reward, 'task');
        alert(`Task "${task.title}" verified! You earned ${CURRENCY_SYMBOL}${task.reward}`);
    }, 5000);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800">Task Wall</h2>
        <p className="text-gray-500">Complete tasks to earn rewards</p>
      </div>

      <div className="space-y-4">
        {tasks.length === 0 && (
            <p className="text-center text-gray-400 py-10">No tasks available at the moment.</p>
        )}
        {tasks.map(task => {
            const Icon = getIcon(task.icon);
            return (
                <div key={task.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-full ${task.color}`}>
                            <Icon size={24} />
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-800">{task.title}</h3>
                            <p className="text-xs text-gray-500">Easy • Instant</p>
                        </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                        <span className="font-bold text-indigo-600 text-lg">+{CURRENCY_SYMBOL}{task.reward}</span>
                        <button 
                            onClick={() => handleTask(task)}
                            className="px-4 py-1.5 bg-gray-900 text-white text-xs font-bold rounded-lg active:scale-95 transition-transform"
                        >
                            START
                        </button>
                    </div>
                </div>
            );
        })}
      </div>
    </div>
  );
};

export default Tasks;
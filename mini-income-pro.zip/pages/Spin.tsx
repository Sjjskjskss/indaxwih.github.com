import React, { useState } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useApp } from '../context/AppContext';
import { SPIN_SEGMENTS, CURRENCY_SYMBOL } from '../constants';
import { Button } from '../components/Button';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const Spin: React.FC = () => {
  const { addBalance, triggerAd, settings } = useApp();
  const navigate = useNavigate();
  const [spinning, setSpinning] = useState(false);
  const controls = useAnimation();
  const [lastRotation, setLastRotation] = useState(0);

  const handleSpin = async () => {
    if (spinning) return;
    setSpinning(true);

    // 1. Trigger Ad FIRST
    try {
        await triggerAd();
    } catch (e) {
        console.error("Ad error", e);
    }

    // 2. Start Spin Animation AFTER Ad
    const randomIndex = Math.floor(Math.random() * SPIN_SEGMENTS.length);
    const segmentAngle = 360 / SPIN_SEGMENTS.length;
    
    // Calculate rotation: Index 0 at top needs 0 offset roughly.
    // Random offset adds realism
    const randomOffset = Math.random() * 20 - 10; 
    const targetAngle = 360 * 5 + (360 - (randomIndex * segmentAngle)) + randomOffset;
    
    await controls.start({
      rotate: lastRotation + targetAngle,
      transition: { duration: 3, ease: "circOut" }
    });

    setLastRotation(lastRotation + targetAngle);
    
    const winAmount = SPIN_SEGMENTS[randomIndex].value;
    
    setTimeout(() => {
        addBalance(winAmount, 'spin');
        alert(`You won ${CURRENCY_SYMBOL}${winAmount}!`);
        setSpinning(false);
    }, 500);
  };

  const isDark = settings.theme !== 'light';

  return (
    <div className={`flex flex-col items-center justify-center min-h-[70vh] space-y-8 ${isDark ? 'text-white' : 'text-gray-900'}`}>
      
      <div className="w-full flex items-center justify-start px-4 absolute top-4 left-0">
          <button onClick={() => navigate('/games')} className="flex items-center gap-2 text-sm font-bold opacity-70 hover:opacity-100">
              <ArrowLeft size={16} /> Back
          </button>
      </div>

      <div className="text-center mt-8">
        <h2 className="text-2xl font-bold">Lucky Wheel</h2>
        <p className="opacity-60">Spin to win up to {CURRENCY_SYMBOL}5</p>
      </div>

      <div className="relative w-64 h-64">
        {/* The Wheel */}
        <motion.div 
            className="w-full h-full rounded-full border-4 border-white shadow-2xl overflow-hidden relative"
            animate={controls}
            style={{ 
                background: `conic-gradient(
                    ${SPIN_SEGMENTS.map((s, i) => 
                        `${s.color} ${(i * 100) / SPIN_SEGMENTS.length}% ${((i + 1) * 100) / SPIN_SEGMENTS.length}%`
                    ).join(', ')}
                )` 
            }}
        >
            {/* Segment Labels */}
            {SPIN_SEGMENTS.map((s, i) => (
                <div 
                    key={i}
                    className="absolute top-0 left-1/2 w-0.5 h-1/2 origin-bottom flex justify-center pt-4"
                    style={{ 
                        transform: `translateX(-50%) rotate(${i * (360 / SPIN_SEGMENTS.length) + (360/SPIN_SEGMENTS.length)/2}deg)` 
                    }}
                >
                    <span className="text-white font-bold text-lg drop-shadow-md -rotate-90">{s.label}</span>
                </div>
            ))}
        </motion.div>
        
        {/* Center Pin */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center border-4 border-gray-100 z-10">
            <span className="text-xs font-bold text-indigo-600">WIN</span>
        </div>

        {/* Indicator Arrow */}
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-8 h-8 z-20">
             <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[20px] border-t-indigo-800 filter drop-shadow-lg"></div>
        </div>
      </div>

      <Button onClick={handleSpin} disabled={spinning} className="w-48 shadow-lg shadow-indigo-500/30">
        {spinning ? 'Spinning...' : 'Spin Now'}
      </Button>
    </div>
  );
};

export default Spin;
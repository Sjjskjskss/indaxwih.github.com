import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CURRENCY_SYMBOL } from '../constants';
import { Button } from '../components/Button';
import { Wallet, History, AlertCircle, Clock, CheckCircle2, XCircle, Phone, Banknote, Check, X, ShieldCheck, MessageCircle } from 'lucide-react';
import { WithdrawalRequest } from '../types';

const Withdraw: React.FC = () => {
  const { user, createWithdrawal, requests, settings } = useApp();
  const [number, setNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'Bkash' | 'Nagad'>('Bkash');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);

    const amt = parseFloat(amount);
    
    if (!number) { setError('Please enter your mobile number.'); return; }
    if (number.length < 11) { setError('Please enter a valid 11-digit mobile number.'); return; }
    if (!amount) { setError('Please enter the amount you wish to withdraw.'); return; }
    if (isNaN(amt) || amt <= 0) { setError('Please enter a valid amount.'); return; }
    if (amt < 50) { setError(`Minimum withdrawal amount is ${CURRENCY_SYMBOL}50.`); return; }
    if (amt > user.balance) { setError(`Insufficient balance. Your current balance is ${CURRENCY_SYMBOL}${user.balance.toFixed(2)}.`); return; }

    setShowConfirm(true);
  };

  const handleConfirm = () => {
    try {
        const amt = parseFloat(amount);
        createWithdrawal(number, amt, method);
        setSuccess(true);
        setNumber('');
        setAmount('');
        setShowConfirm(false);
        setTimeout(() => setSuccess(false), 5000);
    } catch (err: any) {
        setError(err.message || 'An error occurred processing your request.');
        setShowConfirm(false);
    }
  };

  const getStatusStyle = (status: WithdrawalRequest['status']) => {
    switch (status) {
      case 'approved': return { color: 'text-green-600', bg: 'bg-green-50', border: 'border-green-100', icon: <CheckCircle2 size={16} /> };
      case 'rejected': return { color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-100', icon: <XCircle size={16} /> };
      default: return { color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', icon: <Clock size={16} /> };
    }
  };

  const history = [...requests].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="space-y-6 pb-6 relative">
       {/* Balance Card */}
       <div className="relative overflow-hidden bg-gradient-to-br from-indigo-600 to-blue-700 p-6 rounded-2xl text-white shadow-xl shadow-indigo-200">
           <div className="absolute -top-6 -right-6 text-white/10 rotate-12">
               <Wallet size={140} strokeWidth={1} />
           </div>
           <div className="relative z-10">
               <p className="text-indigo-100 text-sm font-medium mb-1 flex items-center gap-2">
                   <Wallet size={16} /> Available Balance
               </p>
               <h2 className="text-4xl font-bold tracking-tight">{CURRENCY_SYMBOL}{user.balance.toFixed(2)}</h2>
               <p className="text-xs text-indigo-200 mt-2 opacity-80 bg-white/10 inline-block px-2 py-1 rounded-md backdrop-blur-sm">
                   Minimum withdrawal: {CURRENCY_SYMBOL}50
               </p>
           </div>
       </div>

       {/* Support Link */}
       {settings?.supportLink && (
           <a 
             href={settings.supportLink} 
             target="_blank" 
             rel="noreferrer"
             className="block w-full bg-blue-50 text-blue-600 text-center py-3 rounded-xl font-bold text-sm border border-blue-100 hover:bg-blue-100 transition-colors flex items-center justify-center gap-2"
           >
               <MessageCircle size={18} /> Join Support Channel
           </a>
       )}

       {/* Withdrawal Form */}
       <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-5">
           <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-800">Request Withdrawal</h3>
           </div>
           
           {error && (
               <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg flex items-start gap-3 animate-fade-in relative shadow-sm">
                   <AlertCircle size={20} className="text-red-600 shrink-0 mt-0.5" />
                   <div className="flex-1">
                       <h4 className="text-sm font-bold text-red-800">Cannot Process Withdrawal</h4>
                       <p className="text-sm text-red-700 mt-0.5 leading-snug">{error}</p>
                   </div>
                   <button type="button" onClick={() => setError('')} className="text-red-400 hover:text-red-700 transition-colors p-1"><X size={16} /></button>
               </div>
           )}
           
           {success && (
               <div className="bg-green-50 border border-green-200 text-green-700 p-4 rounded-xl flex items-center gap-3 animate-fade-in shadow-sm">
                   <div className="bg-green-100 p-1.5 rounded-full"><Check size={18} /></div>
                   <div><p className="font-bold text-sm">Success!</p><p className="text-xs opacity-90">Withdrawal request submitted successfully.</p></div>
               </div>
           )}

           <div>
               <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Payment Method</label>
               <div className="grid grid-cols-2 gap-3">
                   {['Bkash', 'Nagad'].map((m) => (
                       <button
                        key={m}
                        type="button"
                        onClick={() => setMethod(m as any)}
                        className={`relative flex items-center justify-center gap-2 py-3 px-4 rounded-xl border transition-all duration-200 active:scale-95 ${
                            method === m 
                            ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm ring-1 ring-indigo-500' 
                            : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
                        }`}
                       >
                        <span className="font-bold">{m}</span>
                        {method === m && (<div className="absolute top-2 right-2 text-indigo-500"><CheckCircle2 size={12} fill="currentColor" className="text-white" /></div>)}
                       </button>
                   ))}
               </div>
           </div>

           <div className="space-y-4">
                <div className="group">
                    <label className="block text-xs font-medium text-gray-500 mb-1.5 ml-1">Mobile Number</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400 group-focus-within:text-indigo-500 transition-colors"><Phone size={18} /></div>
                        <input type="number" value={number} onChange={e => setNumber(e.target.value)} className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:border-indigo-500 transition-all outline-none text-gray-800 placeholder-gray-400" placeholder="Enter 11 digit number" />
                    </div>
                </div>

                <div className="group">
                    <label className="block text-xs font-medium text-gray-500 mb-1.5 ml-1">Amount</label>
                    <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400 group-focus-within:text-indigo-500 transition-colors"><Banknote size={18} /></div>
                        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:border-indigo-500 transition-all outline-none text-gray-800 placeholder-gray-400" placeholder={`Min ${CURRENCY_SYMBOL}50`} />
                    </div>
                </div>
           </div>

           <Button type="submit" disabled={!amount || !number} className="w-full shadow-lg shadow-indigo-100">Request Withdrawal</Button>
       </form>

       {/* Confirmation Modal */}
       {showConfirm && (
         <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl space-y-5 animate-in fade-in zoom-in duration-200 relative">
                <div className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center"><ShieldCheck size={28} /></div>
                    <h3 className="text-xl font-bold text-gray-800 text-center">Confirm Withdrawal</h3>
                </div>
                <div className="bg-gray-50 p-4 rounded-xl space-y-3 border border-gray-100">
                    <div className="flex justify-between items-center border-b border-gray-200 pb-2 border-dashed">
                        <span className="text-gray-500 text-sm">Amount</span>
                        <span className="font-bold text-xl text-gray-800">{CURRENCY_SYMBOL}{parseFloat(amount).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center border-b border-gray-200 pb-2 border-dashed">
                        <span className="text-gray-500 text-sm">Method</span>
                        <span className="font-bold text-gray-800">{method}</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span className="text-gray-500 text-sm">Number</span>
                        <span className="font-bold text-gray-800 font-mono tracking-wide">{number}</span>
                    </div>
                </div>
                <div className="text-center"><p className="text-xs text-gray-500 leading-relaxed px-2">Please verify the details carefully. Once confirmed, this action cannot be undone and balance will be deducted immediately.</p></div>
                <div className="flex gap-3 pt-2">
                    <Button variant="outline" onClick={() => setShowConfirm(false)} className="flex-1 border-gray-200 hover:bg-gray-50 hover:text-gray-700">Cancel</Button>
                    <Button onClick={handleConfirm} className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white">Confirm</Button>
                </div>
            </div>
         </div>
       )}

       {/* History Section */}
       <div className="space-y-4">
           <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2 px-1"><History size={20} className="text-indigo-600" /> Recent History</h3>
           
           {history.length === 0 ? (
               <div className="text-center py-10 bg-white rounded-2xl border border-dashed border-gray-200">
                   <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3 text-gray-400"><History size={24} /></div>
                   <p className="text-gray-400 text-sm font-medium">No withdrawal requests yet</p>
               </div>
           ) : (
               <div className="space-y-3">
                   {history.map(req => {
                       const style = getStatusStyle(req.status);
                       return (
                           <div key={req.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center group hover:shadow-md transition-all duration-200">
                               <div className="flex items-start gap-3">
                                   <div className={`mt-1 p-2 rounded-full ${style.bg} ${style.color}`}>{style.icon}</div>
                                   <div>
                                       <div className="flex items-center gap-2"><span className="font-bold text-gray-800">{req.method}</span></div>
                                       <p className="text-xs text-gray-500 font-mono mt-0.5 tracking-wide">{req.number}</p>
                                       <p className="text-[10px] text-gray-400 mt-1">{new Date(req.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} • {new Date(req.timestamp).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}</p>
                                   </div>
                               </div>
                               <div className="text-right">
                                   <span className="block font-bold text-gray-800 text-lg">{CURRENCY_SYMBOL}{req.amount}</span>
                                   <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide border ${style.border} ${style.bg} ${style.color}`}>{req.status}</span>
                               </div>
                           </div>
                       );
                   })}
               </div>
           )}
       </div>
    </div>
  );
};

export default Withdraw;
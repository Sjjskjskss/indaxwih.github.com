import React, { useRef, useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { CURRENCY_SYMBOL } from '../constants';
import { Button } from '../components/Button';

const Scratch: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { addBalance } = useApp();
  
  const [isRevealed, setIsRevealed] = useState(false);
  const [reward, setReward] = useState(0);
  const [isScratching, setIsScratching] = useState(false);

  const initCard = () => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const rect = container.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;

    // Fill with grey overlay
    ctx.fillStyle = '#C0C0C0';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add text "Scratch Here"
    ctx.fillStyle = '#6b7280';
    ctx.font = '20px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Scratch Here', canvas.width/2, canvas.height/2);

    // Setup Composite Operation
    ctx.globalCompositeOperation = 'destination-out';
    
    // Reset state
    setIsRevealed(false);
    setReward(Math.floor(Math.random() * 3) + 1);
  };

  useEffect(() => {
    initCard();
    // eslint-disable-next-line
  }, []);

  const handleMouseMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isScratching) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let x, y;

    if ('touches' in e) {
        x = e.touches[0].clientX - rect.left;
        y = e.touches[0].clientY - rect.top;
    } else {
        x = (e as React.MouseEvent).clientX - rect.left;
        y = (e as React.MouseEvent).clientY - rect.top;
    }

    ctx.beginPath();
    ctx.arc(x, y, 20, 0, Math.PI * 2);
    ctx.fill();

    checkReveal();
  };

  const checkReveal = () => {
      const canvas = canvasRef.current;
      if (!canvas || isRevealed) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Sample pixels to check how much is cleared
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const pixels = imageData.data;
      let transparent = 0;
      for (let i = 0; i < pixels.length; i += 4) {
          if (pixels[i + 3] < 128) transparent++;
      }

      if (transparent > (pixels.length / 4) * 0.4) {
          // 40% cleared
          setIsRevealed(true);
          addBalance(reward, 'scratch');
          // Clear entire canvas
          ctx.clearRect(0,0, canvas.width, canvas.height);
      }
  };

  const reset = () => {
      initCard();
  };

  return (
    <div className="flex flex-col items-center gap-6 py-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800">Scratch & Win</h2>
        <p className="text-gray-500">Reveal the prize hidden below</p>
      </div>

      <div 
        ref={containerRef}
        className="relative w-64 h-64 rounded-xl overflow-hidden shadow-xl"
        style={{ touchAction: 'none' }}
      >
        {/* Underlying Reward Layer */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
            <div className="text-center text-white">
                <p className="text-lg font-medium opacity-80">You Won</p>
                <p className="text-5xl font-bold mt-2">{CURRENCY_SYMBOL}{reward}</p>
            </div>
        </div>

        {/* Canvas Scratch Layer */}
        <canvas
            ref={canvasRef}
            className="absolute inset-0 z-10 cursor-crosshair transition-opacity duration-500"
            style={{ opacity: isRevealed ? 0 : 1 }}
            onMouseDown={() => setIsScratching(true)}
            onMouseUp={() => setIsScratching(false)}
            onMouseLeave={() => setIsScratching(false)}
            onMouseMove={handleMouseMove}
            onTouchStart={() => setIsScratching(true)}
            onTouchEnd={() => setIsScratching(false)}
            onTouchMove={handleMouseMove}
        />
      </div>

      {isRevealed && (
          <div className="animate-fade-in w-full max-w-xs">
              <div className="bg-green-100 text-green-700 p-4 rounded-lg text-center mb-4">
                  🎉 Added {CURRENCY_SYMBOL}{reward} to your wallet!
              </div>
              <Button onClick={reset}>Play Again</Button>
          </div>
      )}
      
      {!isRevealed && <p className="text-sm text-gray-400">Rub the card above to reveal</p>}
    </div>
  );
};

export default Scratch;
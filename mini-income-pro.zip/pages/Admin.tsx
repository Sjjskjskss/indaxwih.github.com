import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ADMIN_PASSWORD, CURRENCY_SYMBOL } from '../constants';
import { Button } from '../components/Button';
import { 
  Lock, Check, X, LogOut, LayoutDashboard, Wallet, 
  ListTodo, Settings, Users, Trash2, Plus, Save
} from 'lucide-react';

const Admin: React.FC = () => {
  const { 
    user, requests, updateRequestStatus, 
    tasks, addTask, deleteTask, 
    settings, updateSettings, adminUpdateUser 
  } = useApp();

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'withdraw' | 'tasks' | 'settings' | 'users'>('dashboard');

  // Form States
  const [newTask, setNewTask] = useState({ title: '', reward: '', link: '', icon: 'globe' });
  const [balanceInput, setBalanceInput] = useState('');
  const [tempSettings, setTempSettings] = useState({ ...settings });

  const handleLogin = () => {
    if (password === ADMIN_PASSWORD) {
        setIsAuthenticated(true);
    } else {
        alert('Incorrect Password');
    }
  };

  const handleAddTask = () => {
      if (!newTask.title || !newTask.reward) return;
      addTask({
          id: Date.now().toString(),
          title: newTask.title,
          reward: parseFloat(newTask.reward),
          link: newTask.link || '#',
          icon: newTask.icon as any,
          color: 'bg-indigo-50 text-indigo-600'
      });
      setNewTask({ title: '', reward: '', link: '', icon: 'globe' });
  };

  const handleSaveSettings = () => {
      updateSettings(tempSettings);
      alert('Settings Saved!');
  };

  if (!isAuthenticated) {
      return (
          <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
              <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 w-full max-w-sm">
                  <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Lock size={24} />
                  </div>
                  <h2 className="text-xl font-bold text-center text-gray-800 mb-6">Admin Panel</h2>
                  <input 
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter Password"
                    className="w-full p-3 border border-gray-200 rounded-xl mb-4 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                  <Button onClick={handleLogin}>Login to Control Center</Button>
              </div>
          </div>
      );
  }

  const pendingRequests = requests.filter(r => r.status === 'pending');
  const totalPayout = requests.filter(r => r.status === 'approved').reduce((acc, curr) => acc + curr.amount, 0);

  const NavButton = ({ tab, icon: Icon, label }: any) => (
      <button 
        onClick={() => setActiveTab(tab)}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
            activeTab === tab ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:bg-gray-100'
        }`}
      >
          <Icon size={16} />
          {label}
      </button>
  );

  return (
    <div className="space-y-6 pb-20">
        <div className="flex justify-between items-center bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <h2 className="font-bold text-gray-800">Admin Control</h2>
            <button onClick={() => setIsAuthenticated(false)} className="text-red-500 hover:bg-red-50 p-2 rounded-full">
                <LogOut size={20} />
            </button>
        </div>

        {/* Navigation Tabs - Horizontal Scrollable */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <NavButton tab="dashboard" icon={LayoutDashboard} label="Dash" />
            <NavButton tab="withdraw" icon={Wallet} label="Payouts" />
            <NavButton tab="tasks" icon={ListTodo} label="Tasks" />
            <NavButton tab="users" icon={Users} label="Users" />
            <NavButton tab="settings" icon={Settings} label="Config" />
        </div>

        {/* --- DASHBOARD TAB --- */}
        {activeTab === 'dashboard' && (
            <div className="space-y-4 animate-fade-in">
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-indigo-600 text-white p-4 rounded-xl shadow-lg shadow-indigo-200">
                        <p className="text-indigo-200 text-xs uppercase">Total Payout</p>
                        <h3 className="text-2xl font-bold">{CURRENCY_SYMBOL}{totalPayout}</h3>
                    </div>
                    <div className="bg-pink-500 text-white p-4 rounded-xl shadow-lg shadow-pink-200">
                        <p className="text-pink-200 text-xs uppercase">Pending Req</p>
                        <h3 className="text-2xl font-bold">{pendingRequests.length}</h3>
                    </div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-gray-100">
                    <p className="text-sm text-gray-500 mb-2">System Status</p>
                    <div className="flex items-center gap-2 text-green-600 font-bold text-sm">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        All Systems Operational
                    </div>
                </div>
            </div>
        )}

        {/* --- WITHDRAWALS TAB --- */}
        {activeTab === 'withdraw' && (
            <div className="space-y-4 animate-fade-in">
                <h3 className="font-bold text-gray-800">Withdrawal Requests</h3>
                
                {requests.length === 0 && <p className="text-center text-gray-400 py-10">No records found</p>}
                
                {requests.map(req => (
                    <div key={req.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 relative overflow-hidden">
                        {req.status === 'pending' && <div className="absolute top-0 right-0 bg-yellow-400 text-yellow-900 text-[10px] px-2 py-0.5 font-bold rounded-bl-lg">PENDING</div>}
                        {req.status === 'approved' && <div className="absolute top-0 right-0 bg-green-500 text-white text-[10px] px-2 py-0.5 font-bold rounded-bl-lg">PAID</div>}
                        {req.status === 'rejected' && <div className="absolute top-0 right-0 bg-red-500 text-white text-[10px] px-2 py-0.5 font-bold rounded-bl-lg">REJECTED</div>}

                        <div className="space-y-1 mb-3">
                            <div className="flex justify-between items-end">
                                <span className="text-xs text-gray-400 font-mono">ID: {req.id}</span>
                            </div>
                            <p className="font-bold text-gray-800 text-lg">{req.method} - {req.number}</p>
                            <p className="text-sm text-gray-600">Amount: <span className="font-bold text-indigo-600">{CURRENCY_SYMBOL}{req.amount.toFixed(3)}</span></p>
                            <p className="text-xs text-gray-400">{new Date(req.timestamp).toLocaleString()}</p>
                        </div>

                        {req.status === 'pending' && (
                            <div className="flex gap-2 border-t border-gray-50 pt-3">
                                <button 
                                    onClick={() => updateRequestStatus(req.id, 'approved')}
                                    className="flex-1 bg-green-50 text-green-600 py-2 rounded-lg text-sm font-bold hover:bg-green-100 transition-colors"
                                >
                                    Approve
                                </button>
                                <button 
                                    onClick={() => updateRequestStatus(req.id, 'rejected')}
                                    className="flex-1 bg-red-50 text-red-600 py-2 rounded-lg text-sm font-bold hover:bg-red-100 transition-colors"
                                >
                                    Reject
                                </button>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        )}

        {/* --- TASKS TAB --- */}
        {activeTab === 'tasks' && (
            <div className="space-y-6 animate-fade-in">
                <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                    <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2"><Plus size={18}/> Add New Task</h3>
                    <div className="space-y-3">
                        <input 
                            className="w-full p-2 bg-gray-50 rounded-lg text-sm border border-gray-200" 
                            placeholder="Task Title (e.g. Join Channel)"
                            value={newTask.title}
                            onChange={e => setNewTask({...newTask, title: e.target.value})}
                        />
                        <div className="flex gap-2">
                            <input 
                                className="w-1/2 p-2 bg-gray-50 rounded-lg text-sm border border-gray-200" 
                                placeholder="Reward Amount"
                                type="number"
                                value={newTask.reward}
                                onChange={e => setNewTask({...newTask, reward: e.target.value})}
                            />
                            <select 
                                className="w-1/2 p-2 bg-gray-50 rounded-lg text-sm border border-gray-200"
                                value={newTask.icon}
                                onChange={e => setNewTask({...newTask, icon: e.target.value})}
                            >
                                <option value="globe">Website</option>
                                <option value="youtube">YouTube</option>
                                <option value="telegram">Telegram</option>
                                <option value="star">Rating</option>
                                <option value="download">Install</option>
                            </select>
                        </div>
                        <input 
                            className="w-full p-2 bg-gray-50 rounded-lg text-sm border border-gray-200" 
                            placeholder="Link URL"
                            value={newTask.link}
                            onChange={e => setNewTask({...newTask, link: e.target.value})}
                        />
                        <Button onClick={handleAddTask} className="py-2 text-sm">Create Task</Button>
                    </div>
                </div>

                <div className="space-y-3">
                    <h3 className="font-bold text-gray-800 text-sm uppercase">Active Tasks</h3>
                    {tasks.map(t => (
                        <div key={t.id} className="bg-white p-3 rounded-lg border border-gray-100 flex justify-between items-center">
                            <div>
                                <p className="font-bold text-sm">{t.title}</p>
                                <p className="text-xs text-gray-500">Reward: {CURRENCY_SYMBOL}{t.reward}</p>
                            </div>
                            <button 
                                onClick={() => deleteTask(t.id)}
                                className="text-red-500 bg-red-50 p-2 rounded-lg hover:bg-red-100"
                            >
                                <Trash2 size={16} />
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        )}

        {/* --- USERS TAB --- */}
        {activeTab === 'users' && (
            <div className="space-y-6 animate-fade-in">
                <div className="bg-white p-4 rounded-xl border border-gray-100">
                    <h3 className="font-bold text-gray-800 mb-2">Current User Control</h3>
                    <p className="text-sm text-gray-500 mb-4">Manage the currently logged-in user balance (Local Environment).</p>
                    
                    <div className="bg-gray-50 p-3 rounded-lg mb-4 flex justify-between items-center">
                        <span className="text-gray-600 font-medium">Current Balance</span>
                        <span className="text-xl font-bold text-indigo-600">{CURRENCY_SYMBOL}{user.balance.toFixed(2)}</span>
                    </div>

                    <div className="space-y-3">
                        <Button 
                            variant="danger" 
                            onClick={() => {
                                if(window.confirm('Are you sure you want to remove ALL points?')) adminUpdateUser('reset');
                            }}
                        >
                            <Trash2 size={16} /> Remove All Points
                        </Button>

                        <div className="flex gap-2">
                            <input 
                                className="flex-1 p-2 bg-gray-50 rounded-lg border border-gray-200"
                                placeholder="Amount"
                                type="number"
                                value={balanceInput}
                                onChange={e => setBalanceInput(e.target.value)}
                            />
                            <button 
                                onClick={() => { adminUpdateUser('deduct', parseFloat(balanceInput)); setBalanceInput(''); }}
                                className="bg-orange-100 text-orange-600 px-4 rounded-lg font-bold text-sm hover:bg-orange-200"
                            >
                                Deduct
                            </button>
                            <button 
                                onClick={() => { adminUpdateUser('add', parseFloat(balanceInput)); setBalanceInput(''); }}
                                className="bg-green-100 text-green-600 px-4 rounded-lg font-bold text-sm hover:bg-green-200"
                            >
                                Add
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* --- SETTINGS TAB --- */}
        {activeTab === 'settings' && (
            <div className="space-y-6 animate-fade-in">
                 <div className="bg-white p-4 rounded-xl border border-gray-100 space-y-4">
                     <h3 className="font-bold text-gray-800 mb-2 flex items-center gap-2"><Settings size={18}/> Global Configuration</h3>
                     
                     <div>
                         <label className="text-xs font-bold text-gray-500">Telegram Channel Link</label>
                         <input 
                            className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm mt-1"
                            value={tempSettings.telegramLink}
                            onChange={e => setTempSettings({...tempSettings, telegramLink: e.target.value})}
                         />
                     </div>
                     <div>
                         <label className="text-xs font-bold text-gray-500">WhatsApp Group Link</label>
                         <input 
                            className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm mt-1"
                            value={tempSettings.whatsappLink}
                            onChange={e => setTempSettings({...tempSettings, whatsappLink: e.target.value})}
                         />
                     </div>
                     <div>
                         <label className="text-xs font-bold text-gray-500">Withdrawal Redirect / Support Link</label>
                         <input 
                            className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm mt-1"
                            value={tempSettings.supportLink}
                            onChange={e => setTempSettings({...tempSettings, supportLink: e.target.value})}
                         />
                     </div>
                     <div>
                         <label className="text-xs font-bold text-gray-500">Ad Zone ID (Monetag/Code)</label>
                         <input 
                            className="w-full p-2 bg-gray-50 rounded-lg border border-gray-200 text-sm mt-1"
                            value={tempSettings.adZoneId}
                            onChange={e => setTempSettings({...tempSettings, adZoneId: e.target.value})}
                         />
                     </div>

                     <Button onClick={handleSaveSettings} className="mt-4">
                        <Save size={18} /> Save Changes
                     </Button>
                 </div>
            </div>
        )}

    </div>
  );
};

export default Admin;
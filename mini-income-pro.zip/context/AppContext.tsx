import React, { createContext, useContext, useEffect, useState } from 'react';
import { AppContextType, UserState, WithdrawalRequest, Transaction, Task, AppSettings, AppTheme } from '../types';

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_USER: UserState = {
  balance: 0,
  adsWatched: 0,
  transactions: [],
};

const DEFAULT_TASKS: Task[] = [
  { id: '1', title: 'Join Telegram Channel', reward: 5, icon: 'telegram', color: 'text-blue-500 bg-blue-50', link: 'https://telegram.org' },
  { id: '2', title: 'Subscribe YouTube', reward: 3, icon: 'youtube', color: 'text-red-600 bg-red-50', link: 'https://youtube.com' },
  { id: '3', title: 'Rate Us 5 Stars', reward: 5, icon: 'star', color: 'text-yellow-500 bg-yellow-50', link: '#' },
];

const DEFAULT_SETTINGS: AppSettings = {
  telegramLink: 'https://t.me/yourchannel',
  whatsappLink: 'https://wa.me/yourgroup',
  supportLink: 'https://t.me/support',
  adZoneId: '9055411',
  theme: 'light'
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // --- State Initialization ---
  
  const [user, setUser] = useState<UserState>(() => {
    const saved = localStorage.getItem('mip_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [requests, setRequests] = useState<WithdrawalRequest[]>(() => {
    const saved = localStorage.getItem('mip_requests');
    return saved ? JSON.parse(saved) : [];
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('mip_tasks');
    return saved ? JSON.parse(saved) : DEFAULT_TASKS;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('mip_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  // --- Persistence Effects ---
  useEffect(() => { localStorage.setItem('mip_user', JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem('mip_requests', JSON.stringify(requests)); }, [requests]);
  useEffect(() => { localStorage.setItem('mip_tasks', JSON.stringify(tasks)); }, [tasks]);
  useEffect(() => { localStorage.setItem('mip_settings', JSON.stringify(settings)); }, [settings]);

  // --- Logic ---

  const triggerAd = (): Promise<void> => {
    return new Promise((resolve) => {
      // Logic: Show Monetag Ad
      if (typeof (window as any).show_9055411 === 'function') {
        (window as any).show_9055411().then(() => {
          incrementAds();
          // Small delay after ad close before resolving
          setTimeout(resolve, 500); 
        }).catch((e: any) => {
          console.error("Ad load failed, proceeding anyway", e);
          resolve(); // Resolve anyway so user can play
        });
      } else {
        // Fallback simulation
        console.log("Simulating Ad...");
        setTimeout(() => {
            incrementAds();
            resolve();
        }, 1500);
      }
    });
  };

  const addBalance = (amount: number, type: Transaction['type']) => {
    setUser(prev => ({
      ...prev,
      balance: prev.balance + amount,
      transactions: [
        { id: Date.now().toString(), type, amount, timestamp: Date.now() },
        ...prev.transactions
      ].slice(0, 50)
    }));
  };

  const incrementAds = () => {
    setUser(prev => ({ ...prev, adsWatched: prev.adsWatched + 1 }));
  };

  const createWithdrawal = (number: string, amount: number, method: 'Bkash' | 'Nagad') => {
    if (user.balance < amount) throw new Error("Insufficient balance");
    
    const newRequest: WithdrawalRequest = {
      id: Date.now().toString(),
      number,
      amount,
      method,
      status: 'pending',
      timestamp: Date.now()
    };

    setRequests(prev => [newRequest, ...prev]);
    setUser(prev => ({ ...prev, balance: prev.balance - amount }));
  };

  const updateRequestStatus = (id: string, status: 'approved' | 'rejected') => {
    setRequests(prev => prev.map(req => {
      if (req.id !== id) return req;
      
      if (status === 'rejected' && req.status === 'pending') {
          setUser(u => ({
             ...u,
             balance: u.balance + req.amount,
             transactions: [{ id: Date.now().toString(), type: 'admin', amount: req.amount, timestamp: Date.now() }, ...u.transactions]
          }));
      }
      return { ...req, status };
    }));
  };

  // --- Admin & Settings Actions ---

  const addTask = (task: Task) => {
    setTasks(prev => [...prev, task]);
  };

  const deleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const adminUpdateUser = (action: 'reset' | 'deduct' | 'add', amount: number = 0) => {
    setUser(prev => {
      let newBalance = prev.balance;
      if (action === 'reset') newBalance = 0;
      if (action === 'deduct') newBalance = Math.max(0, prev.balance - amount);
      if (action === 'add') newBalance = prev.balance + amount;

      return {
        ...prev,
        balance: newBalance,
        transactions: [
          { id: Date.now().toString(), type: 'admin', amount: action === 'deduct' ? -amount : (action === 'reset' ? -prev.balance : amount), timestamp: Date.now() },
          ...prev.transactions
        ]
      };
    });
  };

  const toggleTheme = () => {
      setSettings(prev => {
          const next: AppTheme = prev.theme === 'light' ? 'dark' : (prev.theme === 'dark' ? 'glass' : 'light');
          return { ...prev, theme: next };
      });
  };

  return (
    <AppContext.Provider value={{ 
      user, requests, tasks, settings,
      addBalance, createWithdrawal, updateRequestStatus, incrementAds, triggerAd,
      addTask, deleteTask, updateSettings, adminUpdateUser, toggleTheme
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
}
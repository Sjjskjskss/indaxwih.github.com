import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Home, Gamepad2, Wallet, User, ClipboardList, Moon, Sun, Sparkles } from 'lucide-react';
import { APP_NAME } from '../constants';
import { useApp } from '../context/AppContext';

const NavItem = ({ to, icon: Icon, label, active, theme }: { to: string; icon: any; label: string; active: boolean, theme: string }) => {
  const navigate = useNavigate();
  const activeColor = theme === 'dark' ? 'text-indigo-400' : 'text-indigo-600';
  const inactiveColor = theme === 'dark' ? 'text-gray-500 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600';

  return (
    <button 
      onClick={() => navigate(to)}
      className={`flex flex-col items-center justify-center w-full py-2 transition-colors ${active ? activeColor : inactiveColor}`}
    >
      <Icon size={24} strokeWidth={active ? 2.5 : 2} />
      <span className="text-[10px] mt-1 font-medium">{label}</span>
    </button>
  );
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const { settings, toggleTheme } = useApp();
  const { theme } = settings;

  // Theme Base Styles
  const getThemeStyles = () => {
      switch(theme) {
          case 'dark': return 'bg-gray-900 text-white';
          case 'glass': return 'bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 text-white';
          default: return 'bg-gray-50 text-gray-900';
      }
  };

  const getGlassEffect = () => {
      if (theme === 'glass') return 'backdrop-blur-xl bg-white/10 border-white/20 border-b shadow-lg';
      if (theme === 'dark') return 'bg-gray-800 border-gray-700 border-b';
      return 'bg-white/80 backdrop-blur-md border-b border-gray-100';
  };

  const getNavStyles = () => {
      if (theme === 'glass') return 'bg-black/30 backdrop-blur-xl border-t border-white/10 text-white';
      if (theme === 'dark') return 'bg-gray-800 border-t border-gray-700 text-white';
      return 'bg-white border-t border-gray-100 text-gray-800';
  };

  return (
    <div className={`min-h-screen pb-20 max-w-md mx-auto shadow-2xl overflow-hidden relative transition-colors duration-300 ${getThemeStyles()}`}>
      {/* iOS Glass Background Elements */}
      {theme === 'glass' && (
        <>
            <div className="fixed top-0 left-0 w-64 h-64 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -translate-x-10 -translate-y-10 animate-blob"></div>
            <div className="fixed top-0 right-0 w-64 h-64 bg-indigo-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 translate-x-10 -translate-y-10 animate-blob animation-delay-2000"></div>
            <div className="fixed bottom-0 left-1/2 w-64 h-64 bg-pink-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -translate-x-1/2 translate-y-10 animate-blob animation-delay-4000"></div>
        </>
      )}

      {/* Header */}
      <header className={`sticky top-0 z-30 px-6 py-4 flex items-center justify-between transition-all ${getGlassEffect()}`}>
        <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded-lg ${theme === 'light' ? 'bg-indigo-600 text-white' : 'bg-white/20 text-white'}`}>
                <Gamepad2 size={20} fill="currentColor" />
            </div>
            <h1 className={`text-xl font-bold ${theme === 'glass' || theme === 'dark' ? 'text-white' : 'bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-pink-500'}`}>
            {APP_NAME}
            </h1>
        </div>
        
        {/* Theme Toggle */}
        <button 
            onClick={toggleTheme}
            className={`p-2 rounded-full transition-colors ${theme === 'light' ? 'bg-gray-100 text-gray-600' : 'bg-white/10 text-white hover:bg-white/20'}`}
        >
            {theme === 'light' && <Moon size={20} />}
            {theme === 'dark' && <Sparkles size={20} />}
            {theme === 'glass' && <Sun size={20} />}
        </button>
      </header>

      {/* Main Content */}
      <main className="p-4 animate-fade-in relative z-10">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className={`fixed bottom-0 left-0 right-0 z-40 max-w-md mx-auto transition-all ${getNavStyles()}`}>
        <div className="flex justify-between items-center px-2">
          <NavItem to="/" icon={Home} label="Home" active={location.pathname === '/'} theme={theme} />
          <NavItem to="/games" icon={Gamepad2} label="Games" active={location.pathname === '/games' || location.pathname === '/spin' || location.pathname === '/scratch'} theme={theme} />
          <NavItem to="/tasks" icon={ClipboardList} label="Tasks" active={location.pathname === '/tasks'} theme={theme} />
          <NavItem to="/withdraw" icon={Wallet} label="Wallet" active={location.pathname === '/withdraw'} theme={theme} />
          <NavItem to="/admin" icon={User} label="Admin" active={location.pathname === '/admin'} theme={theme} />
        </div>
      </nav>
    </div>
  );
};
export const APP_NAME = "Mini Income Pro";
export const CURRENCY_SYMBOL = "৳";
export const ADMIN_PASSWORD = "Sho123@##";

export const SPIN_SEGMENTS = [
  { label: '1', value: 1, color: '#EF4444' }, // Red
  { label: '5', value: 5, color: '#F59E0B' }, // Amber
  { label: '2', value: 2, color: '#10B981' }, // Emerald
  { label: '0', value: 0, color: '#6B7280' }, // Gray
  { label: '3', value: 3, color: '#3B82F6' }, // Blue
  { label: '4', value: 4, color: '#8B5CF6' }, // Violet
];

export const SCRATCH_COLORS = ['#A855F7', '#EC4899', '#6366F1']; // Gradients for cover

import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Layout } from './components/Layout';

// Pages
import Home from './pages/Home';
import Spin from './pages/Spin';
import Scratch from './pages/Scratch';
import Withdraw from './pages/Withdraw';
import Admin from './pages/Admin';
import GameZone from './pages/GameZone';
import Tasks from './pages/Tasks';

const App: React.FC = () => {
  return (
    <AppProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/games" element={<GameZone />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/spin" element={<Spin />} />
            <Route path="/scratch" element={<Scratch />} />
            <Route path="/withdraw" element={<Withdraw />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </Layout>
      </Router>
    </AppProvider>
  );
};

export default App;